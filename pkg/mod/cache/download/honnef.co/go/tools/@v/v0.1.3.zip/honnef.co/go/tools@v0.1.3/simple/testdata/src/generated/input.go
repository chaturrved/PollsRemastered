package pkg

// want `should use for \{\}`

// the error is produced by generated.go, which pretends that its
// broken code came from this file.

package pkg

import _ "github.com/golang/protobuf/proto" // want `Alas, it is deprecated\.`
